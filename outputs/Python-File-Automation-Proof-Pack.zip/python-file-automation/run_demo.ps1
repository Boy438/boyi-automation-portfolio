$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
python src/generate_sample_data.py
python src/file_inbox.py --input-dir data/raw/inbox --output-dir data/processed --apply
python -m unittest discover -s tests -v
python src/build_assets.py
python src/build_video.py
Write-Host ''
Write-Host 'Demo, tests, images, PDF, and video rebuilt successfully.' -ForegroundColor Green

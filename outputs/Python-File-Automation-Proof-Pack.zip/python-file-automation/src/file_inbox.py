from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import shutil
import time
import unicodedata
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = ROOT / "data" / "raw" / "inbox"
DEFAULT_OUTPUT = ROOT / "data" / "processed"
DEFAULT_CONFIG = ROOT / "config" / "rules.json"

ALLOWED_STATUSES = ("accepted", "duplicate", "quarantined", "ignored")
MANIFEST_FIELDS = [
    "source_name",
    "source_path",
    "extension",
    "size_bytes",
    "sha256",
    "detected_type",
    "status",
    "normalized_name",
    "target_folder",
    "duplicate_of",
    "date_hint",
    "rows",
    "columns",
    "pages",
    "summary",
]
EXCEPTION_FIELDS = ["source_name", "issue", "action", "severity"]
PLAN_FIELDS = ["source_name", "status", "target_folder", "target_name", "action"]


@dataclass
class Rules:
    allowed_extensions: list[str] = field(default_factory=lambda: [".csv", ".json", ".txt", ".pdf"])
    ignored_names: list[str] = field(default_factory=lambda: [".ds_store", "thumbs.db", "readme", "desktop.ini"])
    ignored_prefixes: list[str] = field(default_factory=lambda: [".", "~$"])
    max_file_size_mb: int = 25
    date_formats: list[str] = field(
        default_factory=lambda: [
            "%Y-%m-%d",
            "%Y_%m_%d",
            "%Y%m%d",
            "%m-%d-%Y",
            "%m/%d/%Y",
            "%d-%b-%Y",
            "%B %d %Y",
            "%b %d %Y",
        ]
    )

    @classmethod
    def from_json(cls, path: Path) -> "Rules":
        raw = json.loads(path.read_text(encoding="utf-8"))
        data = dict(raw)
        data["allowed_extensions"] = [str(x).lower() for x in data.get("allowed_extensions", [])]
        return cls(**data)

    def ignored(self, path: Path) -> bool:
        name = path.name.lower()
        return name in {x.lower() for x in self.ignored_names} or any(name.startswith(x.lower()) for x in self.ignored_prefixes)


@dataclass
class FileRecord:
    source_name: str
    source_path: str
    extension: str
    size_bytes: int
    sha256: str = ""
    detected_type: str = "unknown"
    status: str = "accepted"
    normalized_name: str = ""
    target_folder: str = "organized"
    duplicate_of: str = ""
    date_hint: str = ""
    rows: int | None = None
    columns: str = ""
    pages: int | None = None
    summary: str = ""

    def manifest_row(self) -> dict[str, Any]:
        data = asdict(self)
        return {key: data.get(key, "") for key in MANIFEST_FIELDS}


@dataclass
class AuditEvent:
    source_name: str
    issue: str
    action: str
    severity: str = "warning"

    def row(self) -> dict[str, str]:
        return asdict(self)


def clean_token(value: str, fallback: str = "file") -> str:
    normalized = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    normalized = re.sub(r"[^a-z0-9]+", "-", normalized.lower()).strip("-")
    return normalized or fallback


def clean_issue(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_") or "unknown_issue"


def extract_date_hint(name: str, formats: Iterable[str]) -> str:
    candidates = re.findall(r"\d{4}[-_]\d{2}[-_]\d{2}|\d{1,2}[-/]\d{1,2}[-/]\d{4}|\d{1,2}-[A-Za-z]{3}-\d{4}|[A-Za-z]{3,9}\s+\d{1,2},?\s+\d{4}", name)
    for candidate in candidates:
        text = candidate.replace(",", "")
        for fmt in formats:
            try:
                return datetime.strptime(text, fmt).date().isoformat()
            except ValueError:
                continue
    return ""


def normalize_name(source_name: str, detected_type: str, date_hint: str) -> str:
    path = Path(source_name)
    stem = clean_token(path.stem, "file")
    if date_hint:
        stem = re.sub(r"^\d{4}[-_]\d{2}[-_]\d{2}[_-]?", "", stem)
        stem = re.sub(r"^\d{1,2}[-_]\d{1,2}[-_]\d{4}[_-]?", "", stem)
        stem = clean_token(stem, "file")
    extension = path.suffix.lower() or f".{detected_type}"
    if detected_type == "unknown":
        extension = path.suffix.lower() or ""
    prefix = date_hint or "undated"
    return f"{prefix}_{detected_type}_{stem}{extension}"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def detect_type(path: Path, allowed_extensions: Iterable[str]) -> str:
    suffix = path.suffix.lower()
    allowed = {x.lower() for x in allowed_extensions}
    if suffix and suffix not in allowed:
        return "unsupported"
    if suffix in allowed:
        if suffix == ".pdf":
            with path.open("rb") as handle:
                return "pdf" if handle.read(4) == b"%PDF" else "unknown"
        return suffix.lstrip(".")
    sample = path.read_bytes()[:4096]
    if sample[:4] == b"%PDF":
        return "pdf"
    text = sample.decode("utf-8", errors="replace")
    try:
        json.loads(text)
        return "json"
    except (json.JSONDecodeError, ValueError):
        pass
    try:
        csv.Sniffer().sniff(text, delimiters=",;\t|")
        if "\n" in text and len(text.splitlines()[0].split(",")) >= 2:
            return "csv"
    except csv.Error:
        pass
    if text.strip() and sum(ch.isprintable() or ch in "\n\r\t" for ch in text) / max(len(text), 1) > 0.85:
        return "txt"
    return "unknown"


def inspect_metadata(path: Path, detected_type: str) -> tuple[dict[str, Any], list[str]]:
    metadata: dict[str, Any] = {"rows": None, "columns": "", "pages": None, "summary": ""}
    warnings: list[str] = []
    if path.stat().st_size == 0:
        raise ValueError("empty_file")
    if detected_type == "csv":
        with path.open("r", newline="", encoding="utf-8-sig") as handle:
            sample = handle.read(4096)
            handle.seek(0)
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
            except csv.Error:
                dialect = csv.excel
            rows = list(csv.reader(handle, dialect=dialect, strict=True))
        if not rows or not rows[0] or all(not str(cell).strip() for cell in rows[0]):
            raise ValueError("missing_header")
        header = rows[0]
        if len(header) < 2:
            raise ValueError("single_column_csv")
        for line_number, row in enumerate(rows[1:], start=2):
            if len(row) != len(header):
                raise ValueError(f"column_count_mismatch_row_{line_number}")
        metadata["rows"] = max(len(rows) - 1, 0)
        metadata["columns"] = ", ".join(str(x).strip() for x in header)
        metadata["summary"] = f"{metadata['rows']} data rows; {len(header)} columns"
    elif detected_type == "json":
        payload = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(payload, list):
            metadata["rows"] = len(payload)
            metadata["summary"] = f"JSON array with {len(payload)} records"
        elif isinstance(payload, dict):
            items = payload.get("items") or payload.get("records") or payload.get("data")
            metadata["rows"] = len(items) if isinstance(items, list) else None
            metadata["columns"] = ", ".join(str(x) for x in payload.keys())
            metadata["summary"] = f"JSON object with {len(payload)} top-level keys"
        else:
            metadata["summary"] = "JSON scalar value"
    elif detected_type == "txt":
        text = path.read_text(encoding="utf-8", errors="replace")
        metadata["rows"] = len(text.splitlines())
        metadata["summary"] = f"{metadata['rows']} lines; {len(text.split())} words"
    elif detected_type == "pdf":
        reader = PdfReader(str(path))
        metadata["pages"] = len(reader.pages)
        first_text = ""
        if reader.pages:
            first_text = (reader.pages[0].extract_text() or "").strip().replace("\n", " ")
        metadata["summary"] = f"{metadata['pages']} pages"
        if first_text:
            metadata["summary"] += f"; first page: {first_text[:120]}"
        else:
            warnings.append("pdf_has_no_extractable_text")
    return metadata, warnings


def scan_folder(input_dir: Path, rules: Rules) -> tuple[list[FileRecord], list[AuditEvent]]:
    started = time.perf_counter()
    records: list[FileRecord] = []
    events: list[AuditEvent] = []
    for path in sorted(input_dir.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(input_dir).as_posix()
        if rules.ignored(path):
            records.append(
                FileRecord(
                    source_name=relative,
                    source_path=str(path),
                    extension=path.suffix.lower(),
                    size_bytes=path.stat().st_size,
                    status="ignored",
                    target_folder="ignored",
                )
            )
            events.append(AuditEvent(relative, "ignored_system_or_template_file", "leave_in_place", "info"))
            continue
        size = path.stat().st_size
        record = FileRecord(
            source_name=relative,
            source_path=str(path),
            extension=path.suffix.lower(),
            size_bytes=size,
        )
        if size > rules.max_file_size_mb * 1024 * 1024:
            record.status = "quarantined"
            record.target_folder = "quarantine"
            record.summary = f"Exceeds {rules.max_file_size_mb} MB limit"
            records.append(record)
            events.append(AuditEvent(relative, "file_too_large", "copy_to_quarantine", "error"))
            continue
        record.sha256 = sha256_file(path)
        record.detected_type = detect_type(path, rules.allowed_extensions)
        if record.detected_type in {"unsupported", "unknown"}:
            record.status = "quarantined"
            record.target_folder = "quarantine"
            record.summary = "Unsupported or unrecognized file type"
            records.append(record)
            events.append(AuditEvent(relative, "unsupported_or_unrecognized_type", "copy_to_quarantine", "error"))
            continue
        try:
            metadata, warnings = inspect_metadata(path, record.detected_type)
        except Exception as exc:  # noqa: BLE001 - audit the real read failure
            record.status = "quarantined"
            record.target_folder = "quarantine"
            record.summary = str(exc)[:180]
            records.append(record)
            events.append(AuditEvent(relative, clean_issue(str(exc)), "copy_to_quarantine", "error"))
            continue
        record.rows = metadata["rows"]
        record.columns = metadata["columns"]
        record.pages = metadata["pages"]
        record.summary = metadata["summary"]
        record.date_hint = extract_date_hint(relative, rules.date_formats)
        record.normalized_name = normalize_name(relative, record.detected_type, record.date_hint)
        record.target_folder = "organized"
        records.append(record)
        if warnings:
            for warning in warnings:
                events.append(AuditEvent(relative, warning, "manual_review", "warning"))

    groups: dict[str, list[FileRecord]] = defaultdict(list)
    for record in records:
        if record.status == "accepted":
            groups[record.sha256].append(record)
    for group in groups.values():
        if len(group) < 2:
            continue
        def preference(record: FileRecord) -> tuple[int, int, str]:
            lowered = record.source_name.lower()
            marker_count = lowered.count("copy") + lowered.count("(1)") + lowered.count("(2)") + lowered.count("(3)")
            return (marker_count, len(record.source_name), lowered)
        primary = min(group, key=preference)
        for record in group:
            if record is primary:
                continue
            record.status = "duplicate"
            record.target_folder = "duplicates"
            record.duplicate_of = primary.source_name
            events.append(AuditEvent(record.source_name, "duplicate_content", "skip_copy", "warning"))
    return records, events


def summarize(records: list[FileRecord], events: list[AuditEvent], elapsed: float, input_dir: Path) -> dict[str, Any]:
    counts = {status: 0 for status in ALLOWED_STATUSES}
    for record in records:
        counts[record.status] = counts.get(record.status, 0) + 1
    return {
        "input_dir": str(input_dir),
        "files_scanned": len(records),
        "accepted": counts.get("accepted", 0),
        "duplicates": counts.get("duplicate", 0),
        "quarantined": counts.get("quarantined", 0),
        "ignored": counts.get("ignored", 0),
        "audit_events": len(events),
        "bytes_scanned": sum(record.size_bytes for record in records),
        "runtime_seconds": round(elapsed, 4),
    }


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def style_header(worksheet) -> None:
    fill = PatternFill("solid", fgColor="0B1220")
    font = Font(color="FFFFFF", bold=True)
    for cell in worksheet[1]:
        cell.fill = fill
        cell.font = font
        cell.alignment = Alignment(vertical="center")


def build_workbook(path: Path, summary: dict[str, Any], records: list[FileRecord], events: list[AuditEvent]) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "Summary"
    ws["A1"] = "File Inbox Automation"
    ws["A1"].font = Font(size=20, bold=True, color="0B1220")
    ws["A2"] = "Independent demo - synthetic files"
    ws["A2"].font = Font(color="5C677D")
    metrics = [
        ("Files scanned", summary["files_scanned"]),
        ("Organized", summary["accepted"]),
        ("Duplicates skipped", summary["duplicates"]),
        ("Quarantined", summary["quarantined"]),
        ("Ignored", summary["ignored"]),
        ("Audit events", summary["audit_events"]),
        ("Runtime (seconds)", summary["runtime_seconds"]),
    ]
    for index, (label, value) in enumerate(metrics, start=4):
        ws.cell(row=index, column=1, value=label).font = Font(bold=True)
        ws.cell(row=index, column=2, value=value)
    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 20
    chart = BarChart()
    chart.title = "Inbox outcome"
    chart.y_axis.title = "Files"
    chart.add_data(Reference(ws, min_col=2, min_row=6, max_row=9), titles_from_data=False)
    chart.set_categories(Reference(ws, min_col=1, min_row=6, max_row=9))
    chart.height = 7
    chart.width = 14
    ws.add_chart(chart, "D4")

    ws2 = wb.create_sheet("Manifest")
    ws2.append(MANIFEST_FIELDS)
    for record in records:
        ws2.append([record.manifest_row()[field] for field in MANIFEST_FIELDS])
    style_header(ws2)
    ws2.freeze_panes = "A2"
    ws2.auto_filter.ref = ws2.dimensions
    for index, width in enumerate([30, 60, 12, 14, 68, 16, 14, 44, 16, 32, 14, 10, 40, 10, 60], start=1):
        ws2.column_dimensions[get_column_letter(index)].width = width

    ws3 = wb.create_sheet("Exceptions")
    ws3.append(EXCEPTION_FIELDS)
    for event in events:
        ws3.append([event.row()[field] for field in EXCEPTION_FIELDS])
    style_header(ws3)
    ws3.freeze_panes = "A2"
    ws3.auto_filter.ref = ws3.dimensions
    for index, width in enumerate([36, 42, 26, 14], start=1):
        ws3.column_dimensions[get_column_letter(index)].width = width

    ws4 = wb.create_sheet("Plan")
    ws4.append(PLAN_FIELDS)
    for record in records:
        action = "copy" if record.status in {"accepted", "duplicate", "quarantined"} else "skip"
        ws4.append([record.source_name, record.status, record.target_folder, record.normalized_name, action])
    style_header(ws4)
    ws4.freeze_panes = "A2"
    for index, width in enumerate([36, 16, 18, 50, 12], start=1):
        ws4.column_dimensions[get_column_letter(index)].width = width

    for sheet in wb.worksheets:
        sheet.sheet_properties.pageSetUpPr.fitToPage = True
        sheet.page_setup.fitToWidth = 1
        sheet.page_setup.fitToHeight = 0
        sheet.sheet_view.zoomScale = 90
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)


def safe_target(folder: Path, filename: str, digest: str) -> Path:
    target = folder / filename
    if not target.exists():
        return target
    return folder / f"{Path(filename).stem}-{digest[:8]}{Path(filename).suffix}"


def apply_plan(records: list[FileRecord], output_dir: Path) -> list[dict[str, str]]:
    actions: list[dict[str, str]] = []
    for record in records:
        if record.status == "ignored":
            continue
        folder = output_dir / record.target_folder
        folder.mkdir(parents=True, exist_ok=True)
        target = safe_target(folder, record.normalized_name or Path(record.source_name).name, record.sha256 or "nohash")
        shutil.copy2(record.source_path, target)
        actions.append({"source_name": record.source_name, "target": str(target), "status": record.status})
    return actions


def run(input_dir: Path, output_dir: Path, rules: Rules, apply: bool = False) -> dict[str, Any]:
    started = time.perf_counter()
    records, events = scan_folder(input_dir, rules)
    elapsed = time.perf_counter() - started
    summary = summarize(records, events, elapsed, input_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(output_dir / "manifest.csv", [record.manifest_row() for record in records], MANIFEST_FIELDS)
    write_csv(output_dir / "exceptions.csv", [event.row() for event in events], EXCEPTION_FIELDS)
    plan_rows = []
    for record in records:
        plan_rows.append(
            {
                "source_name": record.source_name,
                "status": record.status,
                "target_folder": record.target_folder,
                "target_name": record.normalized_name,
                "action": "copy" if record.status in {"accepted", "duplicate", "quarantined"} else "skip",
            }
        )
    write_csv(output_dir / "organize_plan.csv", plan_rows, PLAN_FIELDS)
    (output_dir / "run_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    build_workbook(output_dir / "file_inbox_report.xlsx", summary, records, events)
    if apply:
        apply_plan(records, output_dir)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description="Scan, classify, deduplicate, and organize a messy file inbox.")
    parser.add_argument("--input-dir", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--apply", action="store_true", help="Copy accepted files into organized/ and bad files into quarantine/.")
    args = parser.parse_args()
    rules = Rules.from_json(args.config)
    summary = run(args.input_dir, args.output_dir, rules, apply=args.apply)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()




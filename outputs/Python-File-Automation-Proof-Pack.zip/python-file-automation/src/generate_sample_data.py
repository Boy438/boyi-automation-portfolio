from __future__ import annotations

import csv
import json
import shutil
from pathlib import Path

from PIL import Image, ImageDraw
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
INBOX = RAW / "inbox"


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def write_pdf(path: Path, title: str, lines: list[str]) -> None:
    pdf = canvas.Canvas(str(path), pagesize=letter)
    width, height = letter
    pdf.setTitle(title)
    pdf.setFont("Helvetica-Bold", 16)
    pdf.drawString(54, height - 62, title)
    pdf.setFont("Helvetica", 10)
    y = height - 96
    for line in lines:
        pdf.drawString(54, y, line)
        y -= 16
    pdf.showPage()
    pdf.save()


def main() -> None:
    if INBOX.exists():
        if INBOX.resolve().parent != RAW.resolve():
            raise RuntimeError(f"Refusing to remove unexpected path: {INBOX}")
        shutil.rmtree(INBOX)
    INBOX.mkdir(parents=True, exist_ok=True)

    vendor_rows = [
        {"vendor_id": "V-001", "vendor_name": "Northwind Supply", "email": "ap@northwind.example", "country": "US", "status": "active"},
        {"vendor_id": "V-002", "vendor_name": "Blue Harbor Ltd", "email": "billing@blueharbor.example", "country": "UK", "status": "active"},
        {"vendor_id": "V-003", "vendor_name": "Sakura Parts", "email": "accounts@sakura.example", "country": "JP", "status": "active"},
        {"vendor_id": "V-004", "vendor_name": "Andes Materials", "email": "finance@andes.example", "country": "CL", "status": "review"},
        {"vendor_id": "V-005", "vendor_name": "Greenline Studio", "email": "hello@greenline.example", "country": "DE", "status": "active"},
        {"vendor_id": "V-006", "vendor_name": "Atlas Freight", "email": "ops@atlasfreight.example", "country": "SG", "status": "active"},
    ]
    write_csv(INBOX / "VENDOR LIST FINAL (3).CSV", vendor_rows)
    shutil.copy2(INBOX / "VENDOR LIST FINAL (3).CSV", INBOX / "vendor list final (3) copy.csv")

    customers = [
        {"customer_id": f"C-{100+i:03d}", "name": f"Customer {i}", "segment": "SMB" if i % 3 else "Enterprise", "country": "US"}
        for i in range(1, 13)
    ]
    (INBOX / "customer_export_2026-03-01.json").write_text(json.dumps(customers, indent=2), encoding="utf-8")
    (INBOX / "customer_export_2026-03-02.json").write_text(json.dumps(customers[:9], indent=2), encoding="utf-8")

    notes = "Kickoff notes\n- Confirm weekly reporting scope\n- Owner: Mia\n- Follow up on vendor master list\n- Next review: Friday\n"
    (INBOX / "notes from kickoff 03-05-2026.txt").write_text(notes, encoding="utf-8")
    (INBOX / "meeting notes 2026-03-05.txt").write_text(notes, encoding="utf-8")

    write_pdf(
        INBOX / "march_statement.pdf",
        "March Statement - Synthetic Demo",
        [
            "Account: DEMO-2048",
            "Statement period: 2026-03-01 to 2026-03-31",
            "Opening balance: 4,250.00",
            "Closing balance: 5,118.40",
            "This is synthetic demo data, not a client document.",
        ],
    )
    shutil.copy2(INBOX / "march_statement.pdf", INBOX / "march statement copy.pdf")

    no_ext = "id,name,amount,status\n1,Alpha,120.00,paid\n2,Beta,80.50,paid\n3,Gamma,44.00,pending\n"
    (INBOX / "export_without_extension").write_text(no_ext, encoding="utf-8")
    (INBOX / "broken_export.csv").write_text('id,name,amount\n1,Alice,10\n2,"Bob,20\n', encoding="utf-8")
    (INBOX / "empty.csv").write_text("", encoding="utf-8")
    (INBOX / "corrupt.pdf").write_text("this is not a pdf", encoding="utf-8")

    image = Image.new("RGB", (64, 64), (183, 243, 74))
    draw = ImageDraw.Draw(image)
    draw.rectangle((16, 16, 48, 48), fill=(11, 18, 32))
    image.save(INBOX / "logo.png")

    (INBOX / ".DS_Store").write_bytes(b"synthetic hidden file")
    (INBOX / "README").write_text("How to use this folder\n", encoding="utf-8")
    (INBOX / "~$orders.xlsx").write_bytes(b"temporary office lock file")

    orders = [
        {"order_id": "ORD-1001", "customer": "Alpha", "amount": "120.00", "status": "paid"},
        {"order_id": "ORD-1002", "customer": "Beta", "amount": "80.50", "status": "paid"},
        {"order_id": "ORD-1003", "customer": "Gamma", "amount": "44.00", "status": "pending"},
        {"order_id": "ORD-1004", "customer": "Delta", "amount": "210.00", "status": "paid"},
        {"order_id": "ORD-1005", "customer": "Epsilon", "amount": "35.25", "status": "refunded"},
        {"order_id": "ORD-1006", "customer": "Zeta", "amount": "99.00", "status": "paid"},
        {"order_id": "ORD-1007", "customer": "Eta", "amount": "18.75", "status": "paid"},
        {"order_id": "ORD-1008", "customer": "Theta", "amount": "310.00", "status": "paid"},
        {"order_id": "ORD-1009", "customer": "Iota", "amount": "64.00", "status": "pending"},
    ]
    write_csv(INBOX / "orders 2026_03_07.csv", orders)
    shutil.copy2(INBOX / "orders 2026_03_07.csv", INBOX / "orders 2026_03_07 (1).csv")

    suppliers = [
        {"sku": "SKU-01", "supplier": "Northwind", "unit_cost": "12.40", "lead_time_days": "5"},
        {"sku": "SKU-02", "supplier": "Blue Harbor", "unit_cost": "8.10", "lead_time_days": "8"},
        {"sku": "SKU-03", "supplier": "Sakura", "unit_cost": "21.75", "lead_time_days": "12"},
        {"sku": "SKU-04", "supplier": "Andes", "unit_cost": "15.00", "lead_time_days": "14"},
    ]
    write_csv(INBOX / "supplier_prices.csv", suppliers)

    weekly_notes = "Weekly operating notes\n- Sales: 14 new orders\n- Ops: 2 vendor follow-ups\n- Finance: reconcile March statement\n- Decision: keep the current review cadence\n"
    (INBOX / "2026-03-08_weekly_notes.txt").write_text(weekly_notes, encoding="utf-8")

    files = sorted(path.name for path in INBOX.iterdir() if path.is_file())
    print(f"Created {len(files)} synthetic files in {INBOX}")
    for name in files:
        print(f"  {name}")


if __name__ == "__main__":
    main()

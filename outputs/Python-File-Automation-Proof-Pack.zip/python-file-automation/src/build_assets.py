from __future__ import annotations

import csv
import html
import json
import shutil
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"
ASSETS = DOCS / "assets"
SAMPLE = DOCS / "sample"
BUILD = ROOT / "build"
PORT = Path(r"D:\FreelanceWorkbench\04_portfolio\python-file-automation")
CHROME = Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe")

for path in (DOCS, ASSETS, SAMPLE, BUILD, PORT / "images", PORT / "pdf", PORT / "copy", PORT / "video"):
    path.mkdir(parents=True, exist_ok=True)

summary = json.loads((ROOT / "data" / "processed" / "run_summary.json").read_text(encoding="utf-8"))
with (ROOT / "data" / "processed" / "manifest.csv").open(encoding="utf-8") as handle:
    manifest = list(csv.DictReader(handle))
with (ROOT / "data" / "processed" / "exceptions.csv").open(encoding="utf-8") as handle:
    exceptions = list(csv.DictReader(handle))
with (ROOT / "data" / "processed" / "organize_plan.csv").open(encoding="utf-8") as handle:
    plan = list(csv.DictReader(handle))

NAVY = "#0B1220"
LIME = "#B7F34A"
WARM = "#F6F3EA"
CORAL = "#FF6B5E"
MUTED = "#5C677D"
LINE = "#DDE2EA"
WHITE = "#FFFFFF"


def esc(value: object) -> str:
    return html.escape(str(value or ""), quote=True)


def fmt_int(value: object) -> str:
    try:
        return f"{int(value):,}"
    except (TypeError, ValueError):
        return str(value or "0")


def status_label(status: str) -> str:
    return {"accepted": "ORGANIZED", "duplicate": "DUPLICATE", "quarantined": "QUARANTINED", "ignored": "IGNORED"}.get(status, status.upper())


def status_class(status: str) -> str:
    return {"accepted": "ok", "duplicate": "warn", "quarantined": "bad", "ignored": "muted"}.get(status, "")


BASE_CSS = """
:root{--navy:#0B1220;--lime:#B7F34A;--warm:#F6F3EA;--coral:#FF6B5E;--muted:#5C677D;--line:#DDE2EA;--white:#fff}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--warm);color:var(--navy);font-family:'Segoe UI',Arial,sans-serif;line-height:1.55}
img{display:block;max-width:100%}a{color:inherit}.wrap{max-width:1180px;margin:0 auto;padding:0 28px}
.nav{position:sticky;top:0;z-index:20;background:rgba(11,18,32,.94);backdrop-filter:blur(12px);border-bottom:1px solid rgba(255,255,255,.08)}
.nav .wrap{display:flex;justify-content:space-between;align-items:center;height:66px;gap:18px}.brand{color:#fff;font-weight:900;letter-spacing:.12em;font-size:13px;text-transform:uppercase}.brand b{color:var(--lime)}
.nav-links{display:flex;gap:18px;flex-wrap:wrap}.nav-links a{color:#C8D0DD;text-decoration:none;font-size:13px;font-weight:700}.nav-links a:hover{color:var(--lime)}
.hero{background:var(--navy);color:#fff;padding:70px 0 60px;position:relative;overflow:hidden}.hero:after{content:'';position:absolute;right:-120px;top:-120px;width:460px;height:460px;border-radius:50%;border:1px solid rgba(183,243,74,.25);box-shadow:0 0 0 46px rgba(183,243,74,.04),0 0 0 92px rgba(183,243,74,.03)}
.eyebrow{display:inline-flex;align-items:center;gap:8px;border:1px solid rgba(183,243,74,.35);background:rgba(183,243,74,.1);color:var(--lime);border-radius:999px;padding:7px 12px;font-size:11px;font-weight:800;letter-spacing:.1em;text-transform:uppercase}.dot{width:7px;height:7px;border-radius:50%;background:var(--lime);display:inline-block}
.hero h1{font-size:clamp(42px,6vw,78px);line-height:1;letter-spacing:-.055em;margin:24px 0 18px;max-width:980px}.hero h1 em{font-style:normal;color:var(--lime)}.hero p{font-size:19px;color:#C8D0DD;max-width:820px;margin:0 0 28px}
.hero-actions{display:flex;gap:12px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;justify-content:center;border-radius:11px;padding:13px 18px;font-weight:800;text-decoration:none;transition:.18s ease;border:0;font:inherit;cursor:pointer}.btn:hover{transform:translateY(-1px);filter:brightness(1.03)}.btn-primary{background:var(--lime);color:var(--navy)}.btn-ghost{background:rgba(255,255,255,.08);color:#fff;border:1px solid rgba(255,255,255,.2)}.btn-dark{background:var(--navy);color:#fff}.btn-outline{background:transparent;color:var(--navy);border:1px solid #C8D0DD}
.metric-row{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-top:34px}.metric{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.11);border-radius:16px;padding:18px 20px}.metric b{display:block;color:var(--lime);font-size:30px;line-height:1.1;letter-spacing:-.03em}.metric span{display:block;color:#AAB5C4;font-size:11px;text-transform:uppercase;letter-spacing:.09em;margin-top:6px}
section{padding:68px 0}section.tight{padding:34px 0}.kicker{font-size:12px;font-weight:800;letter-spacing:.15em;text-transform:uppercase;color:var(--muted);margin:0 0 12px}h2{font-size:clamp(30px,3.6vw,50px);line-height:1.06;letter-spacing:-.04em;margin:0 0 16px}.lead{font-size:18px;color:#435066;max-width:850px;margin:0 0 28px}
.demo-shell{background:var(--navy);border-radius:22px;padding:24px;color:#fff;box-shadow:0 24px 60px rgba(11,18,32,.18)}.demo-top{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;margin-bottom:18px}.demo-title{font-size:22px;font-weight:800}.demo-sub{font-size:13px;color:#AAB5C4;margin-top:4px}.demo-state{font-size:12px;color:var(--lime);font-weight:800;letter-spacing:.08em;text-transform:uppercase}.demo-chips{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:0 0 18px}.chip{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);border-radius:12px;padding:12px 14px}.chip b{display:block;color:var(--lime);font-size:23px;line-height:1.1}.chip span{display:block;color:#AAB5C4;font-size:11px;text-transform:uppercase;letter-spacing:.08em;margin-top:3px}
table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:11px 12px;border-bottom:1px solid rgba(255,255,255,.1);font-size:13px;vertical-align:top}th{color:#AAB5C4;font-size:11px;text-transform:uppercase;letter-spacing:.08em;font-weight:800}td.mono{font-family:Consolas,monospace;font-size:12px;word-break:break-word}.result{color:#C8D0DD}.result.ready{color:var(--lime)}.badge{display:inline-flex;border-radius:999px;padding:4px 8px;font-size:10px;font-weight:900;letter-spacing:.06em}.badge.ok{background:rgba(183,243,74,.16);color:var(--lime)}.badge.warn{background:rgba(255,184,77,.16);color:#FFC36A}.badge.bad{background:rgba(255,107,94,.16);color:#FF8A80}.badge.muted{background:rgba(255,255,255,.1);color:#C8D0DD}
.grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}.grid4{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}.card{background:#fff;border:1px solid var(--line);border-radius:17px;padding:21px;box-shadow:0 10px 30px rgba(11,18,32,.04)}.card h3{font-size:17px;margin:0 0 8px}.card p{color:#4B586D;font-size:14px;margin:0}.card .big{font-size:34px;font-weight:900;letter-spacing:-.04em;color:var(--navy);line-height:1}
.process{background:#fff;border:1px solid var(--line);border-radius:16px;padding:20px}.process .num{width:32px;height:32px;border-radius:10px;background:var(--lime);display:flex;align-items:center;justify-content:center;font-weight:900;margin-bottom:14px}.process h3{font-size:16px;margin:0 0 7px}.process p{font-size:13px;color:#4B586D;margin:0}
.split{display:grid;grid-template-columns:1.05fr .95fr;gap:24px;align-items:start}.panel{background:#fff;border:1px solid var(--line);border-radius:18px;padding:22px;box-shadow:0 10px 30px rgba(11,18,32,.04)}.panel h3{margin:0 0 12px;font-size:18px}.checklist{list-style:none;padding:0;margin:0;display:grid;gap:10px}.checklist li{display:flex;gap:10px;align-items:flex-start;font-size:14px}.check{width:20px;height:20px;border-radius:50%;background:var(--lime);display:inline-flex;align-items:center;justify-content:center;font-weight:900;font-size:12px;flex:none}.note{font-size:12px;color:var(--muted)}
.sample-list{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}.sample{display:flex;justify-content:space-between;gap:12px;background:#fff;border:1px solid var(--line);border-radius:12px;padding:13px 15px;text-decoration:none;font-size:14px}.sample span{color:var(--muted);font-size:12px}.sample b{font-family:Consolas,monospace;font-size:12px}.footer{padding:28px 0 40px;color:var(--muted);font-size:12px;border-top:1px solid var(--line);margin-top:20px}
@media(max-width:900px){.metric-row,.demo-chips{grid-template-columns:1fr 1fr}.grid4,.grid3,.split,.sample-list{grid-template-columns:1fr}.hero h1{font-size:46px}.demo-top{display:block}.demo-top .btn{margin-top:14px}}
"""
PRINT_CSS = """
@page{size:Letter;margin:0}*{box-sizing:border-box}body{margin:0;font-family:'Segoe UI',Arial,sans-serif;color:#0B1220;background:#fff;line-height:1.42}
.print-page{width:8.5in;height:11in;padding:.55in .62in;page-break-after:always;position:relative;overflow:hidden;background:#F6F3EA}.print-page:last-child{page-break-after:auto}.print-page.cover{background:#0B1220;color:#fff}.eyebrow{display:inline-flex;gap:8px;border:1px solid rgba(183,243,74,.4);background:rgba(183,243,74,.12);color:#B7F34A;border-radius:999px;padding:6px 10px;font-size:9px;font-weight:800;letter-spacing:.12em;text-transform:uppercase}.dot{width:6px;height:6px;border-radius:50%;background:#B7F34A;display:inline-block}.print-page h1{font-size:48px;line-height:1.02;letter-spacing:-.05em;margin:22px 0 12px}.print-page h1 em{font-style:normal;color:#B7F34A}.print-page h2{font-size:28px;line-height:1.1;letter-spacing:-.035em;margin:0 0 10px}.print-page h3{font-size:15px;margin:0 0 5px}.print-page p{font-size:11px;margin:0 0 8px}.kicker{font-size:9px;font-weight:900;letter-spacing:.15em;text-transform:uppercase;color:#5C677D;margin:0 0 8px}.metric-row{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:18px}.metric{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:10px}.metric b{display:block;color:#B7F34A;font-size:22px}.metric span{display:block;color:#AAB5C4;font-size:8px;text-transform:uppercase;letter-spacing:.08em}.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}.card{background:#fff;border:1px solid #DDE2EA;border-radius:12px;padding:12px}.card p{color:#4B586D}.big{font-size:30px;font-weight:900;color:#0B1220}.table{width:100%;border-collapse:collapse;margin-top:8px}.table th,.table td{text-align:left;border-bottom:1px solid #DDE2EA;padding:6px 7px;font-size:9px;vertical-align:top}.table th{background:#0B1220;color:#fff;font-size:8px;text-transform:uppercase;letter-spacing:.06em}.code{font-family:Consolas,monospace;font-size:8px;word-break:break-word}.note{font-size:9px;color:#5C677D}.list{list-style:none;padding:0;margin:8px 0}.list li{display:flex;gap:7px;margin:0 0 6px;font-size:10px}.check{width:15px;height:15px;border-radius:50%;background:#B7F34A;display:inline-flex;align-items:center;justify-content:center;font-size:9px;font-weight:900;flex:none}.step{background:#fff;border:1px solid #DDE2EA;border-radius:10px;padding:9px}.step b{display:block;font-size:9px;color:#5C677D}.step strong{display:block;font-size:12px;margin:3px 0}.step span{font-size:9px;color:#4B586D}.footer-note{position:absolute;left:.62in;bottom:.35in;font-size:8px;color:#5C677D}
"""

GIG_CSS = """
*{box-sizing:border-box}html,body{margin:0;background:#0B1220;color:#fff;font-family:'Segoe UI',Arial,sans-serif;overflow:hidden}.canvas{position:relative;width:100vw;height:100vh;overflow:hidden;background:#0B1220;padding:54px 62px}.rings{position:absolute;right:-120px;top:-120px;width:460px;height:460px;border:1px solid rgba(183,243,74,.3);border-radius:50%;box-shadow:0 0 0 46px rgba(183,243,74,.04),0 0 0 92px rgba(183,243,74,.03)}.brand{font-size:15px;letter-spacing:.16em;text-transform:uppercase;color:#B7F34A;font-weight:900}.kicker{font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:#AAB5C4;font-weight:800}.title{font-size:76px;line-height:.98;letter-spacing:-.055em;font-weight:900;margin:18px 0 12px;max-width:980px}.title em{font-style:normal;color:#B7F34A}.sub{font-size:22px;color:#C8D0DD;max-width:840px}.chips{display:flex;flex-wrap:wrap;gap:10px;margin-top:26px}.chip{border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);border-radius:10px;padding:10px 14px;font-size:15px}.metrics{display:flex;gap:12px;margin-top:28px}.metric{min-width:150px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);border-radius:14px;padding:13px 16px}.metric b{display:block;color:#B7F34A;font-size:28px}.metric span{display:block;color:#AAB5C4;font-size:10px;text-transform:uppercase;letter-spacing:.09em}.footer{position:absolute;left:62px;bottom:34px;color:#AAB5C4;font-size:12px}.cols{display:grid;grid-template-columns:1fr 1fr;gap:26px;margin-top:26px}.col{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.12);border-radius:16px;padding:18px}.col h3{margin:0 0 12px;font-size:16px;color:#B7F34A}.col p{font-size:12px;color:#AAB5C4;margin:0 0 10px}.stack{display:grid;gap:10px}.file{display:flex;justify-content:space-between;gap:12px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.13);border-radius:10px;padding:10px 12px;font-family:Consolas,monospace;font-size:12px}.file.bad{border-color:rgba(255,107,94,.45);color:#FFB1AA}.file.good{border-color:rgba(183,243,74,.4)}.file span{color:#AAB5C4;font-family:'Segoe UI',Arial,sans-serif}.steps{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-top:44px}.step{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.13);border-radius:14px;padding:15px}.step b{display:block;color:#B7F34A;font-size:11px;letter-spacing:.1em}.step strong{display:block;font-size:16px;margin:8px 0 6px}.step span{font-size:11px;color:#AAB5C4}.bottom{display:flex;justify-content:space-between;gap:20px;margin-top:28px;border-top:1px solid rgba(255,255,255,.14);padding-top:16px;color:#C8D0DD;font-size:12px}
"""


def page(title: str, body: str, css: str = BASE_CSS, extra_head: str = "") -> str:
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title>{extra_head}<style>{css}</style></head><body>{body}</body></html>"""


def selected_rows() -> list[dict[str, str]]:
    wanted = [
        "VENDOR LIST FINAL (3).CSV",
        "customer_export_2026-03-01.json",
        "march_statement.pdf",
        "export_without_extension",
        "2026-03-08_weekly_notes.txt",
        "orders 2026_03_07 (1).csv",
        "march statement copy.pdf",
        "broken_export.csv",
        "empty.csv",
        "logo.png",
        ".DS_Store",
    ]
    index = {row["source_name"]: row for row in manifest}
    return [index[name] for name in wanted if name in index]

def build_case_page() -> Path:
    rows = selected_rows()
    row_html = []
    for row in rows:
        status = row["status"]
        if status == "accepted":
            result = row["normalized_name"]
        elif status == "duplicate":
            result = f"Skip copy - duplicate of {row['duplicate_of']}"
        elif status == "quarantined":
            result = f"Quarantine - {row['summary'] or 'needs review'}"
        else:
            result = "Leave in place - system/template file"
        row_html.append(
            f'<tr data-result="{esc(result)}"><td class="mono">{esc(row["source_name"])}</td>'
            f'<td><span class="badge {status_class(status)}">{status_label(status)}</span></td>'
            f'<td class="result">{esc(result)}</td></tr>'
        )
    body_top = f"""
<nav class="nav"><div class="wrap"><div class="brand">BOYI <b>AUTOMATION</b></div><div class="nav-links"><a href="#demo">Interactive demo</a><a href="#outputs">Outputs</a><a href="#validation">Validation</a></div></div></nav>
<div class="hero"><div class="wrap">
  <span class="eyebrow"><span class="dot"></span> Independent demo - synthetic files</span>
  <h1>Messy file inbox.<br><em>Clean, auditable folder.</em></h1>
  <p>Python automation that scans a messy folder, detects file types, catches duplicates and corrupt files, normalizes names, and produces a reviewable report - before anything is moved.</p>
  <div class="hero-actions"><a class="btn btn-primary" href="#demo">Run the demo</a><a class="btn btn-ghost" href="#outputs">See the outputs</a></div>
  <div class="metric-row"><div class="metric"><b>{fmt_int(summary["files_scanned"])}</b><span>files scanned</span></div><div class="metric"><b>{fmt_int(summary["accepted"])}</b><span>organized</span></div><div class="metric"><b>{fmt_int(summary["duplicates"])}</b><span>duplicates skipped</span></div><div class="metric"><b>10/10</b><span>tests passed</span></div></div>
</div></div>

<section id="demo"><div class="wrap">
  <p class="kicker">Interactive proof</p><h2>One click. Every file accounted for.</h2><p class="lead">This is a deterministic Python pipeline, not a black box. The demo starts with a dry run: scan, classify, validate, and plan. Nothing is deleted.</p>
  <div class="demo-shell">
    <div class="demo-top"><div><div class="demo-title">Folder audit</div><div class="demo-sub">Synthetic inbox - {fmt_int(summary["files_scanned"])} files - SHA-256 duplicate detection - safe copy only</div></div><button class="btn btn-primary" id="run-demo">Run folder audit</button></div>
    <div class="demo-chips"><div class="chip"><b id="chip-scanned">-</b><span>scanned</span></div><div class="chip"><b id="chip-organized">-</b><span>organized</span></div><div class="chip"><b id="chip-duplicates">-</b><span>duplicates</span></div><div class="chip"><b id="chip-quarantine">-</b><span>quarantined</span></div></div>
    <div class="demo-state" id="run-state">Ready - dry run</div>
    <table><thead><tr><th>Source file</th><th>Status</th><th>Planned result</th></tr></thead><tbody>{''.join(row_html)}</tbody></table>
  </div>
  <p class="note" style="margin-top:12px">The page shows a representative slice of the 20-file audit. The downloadable manifest contains every row.</p>
</div></section>
"""
    body_bottom = f"""
<section id="outputs" class="tight"><div class="wrap"><p class="kicker">Outputs</p><h2>A report you can review, not a folder you have to trust.</h2><div class="grid4">
  <div class="card"><div class="big">{fmt_int(summary["accepted"])}</div><h3>Organized copies</h3><p>Normalized names in a separate output folder. The source folder is untouched.</p></div>
  <div class="card"><div class="big">{fmt_int(summary["duplicates"])}</div><h3>Duplicates skipped</h3><p>Byte-identical files are kept for review and never copied into the clean set.</p></div>
  <div class="card"><div class="big">{fmt_int(summary["quarantined"])}</div><h3>Quarantined</h3><p>Empty, malformed, unsupported, or corrupt files are separated with a reason.</p></div>
  <div class="card"><div class="big">{fmt_int(summary["audit_events"])}</div><h3>Audit events</h3><p>Every duplicate, quarantine, and ignored file has a visible action trail.</p></div>
</div></div></section>

<section class="tight"><div class="wrap"><div class="split"><div class="panel"><h3>What the client gets</h3><ul class="checklist"><li><span class="check">✓</span><div><b>file_inbox_report.xlsx</b> - summary, manifest, exceptions, plan</div></li><li><span class="check">✓</span><div><b>manifest.csv</b> - type, hash, metadata, status, normalized name</div></li><li><span class="check">✓</span><div><b>exceptions.csv</b> - duplicate and quarantine reasons</div></li><li><span class="check">✓</span><div><b>organize_plan.csv</b> - source-to-target copy plan</div></li><li><span class="check">✓</span><div><b>Source + README</b> - rerun the same workflow next month</div></li></ul></div><div class="panel"><h3>Built for cautious operators</h3><ul class="checklist"><li><span class="check">✓</span><div>Dry run by default; no source file is deleted</div></li><li><span class="check">✓</span><div>SHA-256 duplicate detection, not just file-name matching</div></li><li><span class="check">✓</span><div>Clean source name wins over a "copy" or "(1)" file</div></li><li><span class="check">✓</span><div>Human review queue for PDF/CSV edge cases</div></li><li><span class="check">✓</span><div>No account credentials needed for a sample run</div></li></ul></div></div></div></section>

<section><div class="wrap"><p class="kicker">Workflow</p><h2>Five steps. One visible decision at each step.</h2><div class="grid4">
  <div class="process"><div class="num">1</div><h3>Scan</h3><p>Walk the inbox, capture names, sizes, and SHA-256 hashes.</p></div>
  <div class="process"><div class="num">2</div><h3>Detect</h3><p>CSV, JSON, TXT, PDF, or content-sniffed file without an extension.</p></div>
  <div class="process"><div class="num">3</div><h3>Validate</h3><p>Check empty files, malformed CSV, corrupt PDF, unsupported types, and duplicates.</p></div>
  <div class="process"><div class="num">4</div><h3>Plan</h3><p>Decide organize, skip, ignore, or quarantine with a written reason.</p></div>
  <div class="process"><div class="num">5</div><h3>Apply safely</h3><p>Copy only when asked; write the manifest and exception log every run.</p></div>
</div></div></section>

<section id="validation" class="tight"><div class="wrap"><p class="kicker">Validation</p><h2>Bad files are not hidden. They are explained.</h2><div class="grid3">
  <div class="card"><div class="big">10/10</div><h3>Automated tests</h3><p>Content detection, duplicate handling, quarantine logic, safe apply, and end-to-end output.</p></div>
  <div class="card"><div class="big">{fmt_int(summary["files_scanned"])}</div><h3>Files in the audit</h3><p>9 accepted, 4 duplicates, 4 quarantined, 3 ignored. The manifest lists every one.</p></div>
  <div class="card"><div class="big">{summary["runtime_seconds"]:.3f}s</div><h3>Demo runtime</h3><p>Measured on the generated local folder. Not a promise for network drives or large batches.</p></div>
</div>
<div class="panel" style="margin-top:16px"><h3>Sample downloads</h3><div class="sample-list"><a class="sample" href="sample/manifest.csv"><b>manifest.csv</b><span>CSV</span></a><a class="sample" href="sample/exceptions.csv"><b>exceptions.csv</b><span>CSV</span></a><a class="sample" href="sample/run_summary.json"><b>run_summary.json</b><span>JSON</span></a><a class="sample" href="sample/organize_plan.csv"><b>organize_plan.csv</b><span>CSV</span></a><a class="sample" href="sample/file_inbox_report.xlsx"><b>file_inbox_report.xlsx</b><span>XLSX</span></a><a class="sample" href="sample/messy_inbox_sample.zip"><b>messy_inbox_sample.zip</b><span>20 files</span></a></div><p class="note" style="margin-top:14px">Sample outputs are generated from synthetic files. The PDF case study and demo video are below.</p><div class="hero-actions" style="margin-top:14px"><a class="btn btn-dark" href="case-study.pdf">Download case study PDF</a><a class="btn btn-outline" href="assets/demo.mp4">Watch the 80-second demo</a></div></div>
</div></section>

<section class="tight"><div class="wrap"><div class="split"><div class="panel"><h3>Good fit</h3><ul class="checklist"><li><span class="check">✓</span><div>Shared drives, download folders, client intake folders, and monthly exports</div></li><li><span class="check">✓</span><div>Mixed CSV, JSON, TXT, and typed PDF files</div></li><li><span class="check">✓</span><div>Teams that need a clean naming convention and a visible audit trail</div></li><li><span class="check">✓</span><div>One-off cleanup that may become a recurring folder workflow</div></li></ul></div><div class="panel"><h3>Not a fit</h3><ul class="checklist"><li><span class="check">—</span><div>Handwritten scans or low-quality images that need OCR review</div></li><li><span class="check">—</span><div>Requests that need account passwords or unattended access</div></li><li><span class="check">—</span><div>Deleting files without a review step or written retention policy</div></li><li><span class="check">—</span><div>"100% accuracy" or unlimited revisions without a spec</div></li></ul></div></div></div></section>

<section class="tight"><div class="wrap"><div class="panel"><h3>Demo limits and disclosure</h3><p style="color:#4B586D;font-size:14px;margin:0">This is an independent demo on synthetic files. It does not connect to Google Drive, Dropbox, SharePoint, email, or a database. The default command is a dry run; <span class="mono">--apply</span> copies files into a separate output folder and never deletes the source. PDF metadata is limited to page count and extractable first-page text. AI-assisted build with human review and testing; the runtime pipeline is deterministic and does not call an external model. Ambiguous dates are parsed as US-style month/day/year in this demo.</p></div></div></section>

<div class="wrap"><div class="footer">Independent demo - synthetic files only - no client names, logos, testimonials, or revenue claims - © 2026 CHEN BOYI / Boyi Automation</div></div>
"""
    js = """
const btn = document.getElementById('run-demo');
const state = document.getElementById('run-state');
const rows = [...document.querySelectorAll('tr[data-result]')];
const chips = {scanned: document.getElementById('chip-scanned'), organized: document.getElementById('chip-organized'), duplicates: document.getElementById('chip-duplicates'), quarantine: document.getElementById('chip-quarantine')};
btn.addEventListener('click', () => {
  btn.disabled = true; state.textContent = 'Scanning - hashing - validating';
  rows.forEach(r => { r.querySelector('.result').textContent = 'Queued'; r.querySelector('.result').classList.remove('ready'); });
  rows.forEach((row, i) => setTimeout(() => {
    const cell = row.querySelector('.result'); cell.textContent = row.dataset.result; cell.classList.add('ready');
    if (i === rows.length - 1) {
      chips.scanned.textContent = '__SCANNED__'; chips.organized.textContent = '__ORGANIZED__'; chips.duplicates.textContent = '__DUPLICATES__'; chips.quarantine.textContent = '__QUARANTINE__';
      state.textContent = 'Run complete - dry run - source untouched'; btn.disabled = false; btn.textContent = 'Run again';
    }
  }, 120 * (i + 1)));
});
"""
    js = js.replace('__SCANNED__', fmt_int(summary['files_scanned'])).replace('__ORGANIZED__', fmt_int(summary['accepted'])).replace('__DUPLICATES__', fmt_int(summary['duplicates'])).replace('__QUARANTINE__', fmt_int(summary['quarantined']))
    body = body_top + body_bottom + '<script>' + js + '</script>'
    path = DOCS / 'index.html'
    path.write_text(page('Messy File Inbox -> Clean Folder | Boyi Automation', body), encoding='utf-8')
    return path

def build_print_page() -> Path:
    body = f"""
<div class="print-page cover"><span class="eyebrow"><span class="dot"></span> INDEPENDENT DEMO - SYNTHETIC FILES</span><h1>Messy file inbox.<br><em>Clean, auditable folder.</em></h1><p style="font-size:16px;color:#C8D0DD;max-width:6.6in">Python automation that scans, classifies, validates, deduplicates, and plans a safe folder cleanup.</p><div class="metric-row"><div class="metric"><b>{fmt_int(summary["files_scanned"])}</b><span>files scanned</span></div><div class="metric"><b>{fmt_int(summary["accepted"])}</b><span>organized</span></div><div class="metric"><b>{fmt_int(summary["duplicates"])}</b><span>duplicates skipped</span></div><div class="metric"><b>10/10</b><span>tests passed</span></div></div><img src="assets/gig-02-before-after.png" alt="Before and after file inbox" style="width:100%;margin-top:18px;border-radius:12px;border:1px solid rgba(255,255,255,.16)"><div class="grid2" style="margin-top:14px"><div class="card" style="background:rgba(255,255,255,.06);border-color:rgba(255,255,255,.14)"><h3 style="color:#B7F34A">Visible decisions</h3><p style="color:#C8D0DD">Every duplicate, quarantine, and ignored file has a status and a reason.</p></div><div class="card" style="background:rgba(255,255,255,.06);border-color:rgba(255,255,255,.14)"><h3 style="color:#B7F34A">Safe by default</h3><p style="color:#C8D0DD">Dry run first. The source folder is never deleted or modified.</p></div></div><p style="margin-top:14px;color:#AAB5C4;font-size:10px">No client names, logos, testimonials, or revenue claims. Synthetic files only.</p></div>
<div class="print-page"><p class="kicker">01 - The problem</p><h2>A folder is not a system.</h2><p>Inconsistent names, duplicate copies, corrupt exports, and unsupported files create a review burden. A manual cleanup hides decisions; the next batch recreates the same mess.</p><div class="grid2" style="margin-top:12px"><div class="card"><h3>Before</h3><p class="code">VENDOR LIST FINAL (3).CSV<br>vendor list final (3) copy.csv<br>march statement copy.pdf<br>broken_export.csv<br>empty.csv<br>logo.png</p></div><div class="card"><h3>After</h3><p class="code">2026-03-01_csv_vendor-list-final-3.csv<br>undated_pdf_march-statement.pdf<br>2026-03-07_csv_orders-2026-03-07.csv<br>quarantine/broken_export.csv<br>quarantine/empty.csv<br>quarantine/logo.png</p></div></div><h2 style="font-size:20px;margin-top:16px">The decision matrix</h2><table class="table"><thead><tr><th>Status</th><th>Meaning</th><th>Action</th></tr></thead><tbody><tr><td>Organized</td><td>Valid, recognized, and the clean copy of a file</td><td>Copy to <span class="code">organized/</span></td></tr><tr><td>Duplicate</td><td>Byte-identical to an already accepted file</td><td>Copy to <span class="code">duplicates/</span> for review</td></tr><tr><td>Quarantined</td><td>Empty, malformed, corrupt, or unsupported</td><td>Copy to <span class="code">quarantine/</span> with reason</td></tr><tr><td>Ignored</td><td>System or template file that is not business data</td><td>Leave in place; list in manifest</td></tr></tbody></table><p class="note" style="margin-top:10px">The rule: scan first. Validate second. Plan third. Apply only with an explicit flag. Keep the source, the manifest, and the exception log.</p><h2 style="font-size:20px;margin-top:14px">Representative manifest</h2><table class="table"><thead><tr><th>Source</th><th>Status</th><th>Target / reason</th></tr></thead><tbody><tr><td class="code">VENDOR LIST FINAL (3).CSV</td><td>Organized</td><td class="code">2026-03-01_csv_vendor-list-final-3.csv</td></tr><tr><td class="code">vendor list final (3) copy.csv</td><td>Duplicate</td><td class="code">duplicates/ - skip copy</td></tr><tr><td class="code">customer_export_2026-03-01.json</td><td>Organized</td><td class="code">2026-03-01_json_customer-export-2026-03-01.json</td></tr><tr><td class="code">export_without_extension</td><td>Organized</td><td class="code">undated_csv_export-without-extension.csv</td></tr><tr><td class="code">broken_export.csv</td><td>Quarantined</td><td class="code">quarantine/ - unexpected end of data</td></tr><tr><td class="code">logo.png</td><td>Quarantined</td><td class="code">quarantine/ - unsupported type</td></tr></tbody></table></div>
<div class="print-page"><p class="kicker">02 - The build</p><h2>Python does the repetitive work. The audit trail stays visible.</h2><div class="grid2"><div class="card"><h3>What it does</h3><ul class="list"><li><span class="check">✓</span>SHA-256 duplicate detection</li><li><span class="check">✓</span>Content sniffing for extensionless files</li><li><span class="check">✓</span>CSV / JSON / TXT / PDF metadata</li><li><span class="check">✓</span>Safe copy into organized / duplicates / quarantine</li><li><span class="check">✓</span>Excel summary + manifest + exceptions + plan</li></ul></div><div class="card"><h3>Validation snapshot</h3><div class="big">{summary["runtime_seconds"]:.3f}s</div><p>Runtime on the 20-file synthetic demo.</p><div class="big">10/10</div><p>Automated tests passed.</p><p class="note">Not a promise for network drives or large batches.</p></div></div><h2 style="font-size:20px;margin-top:14px">Deliverables</h2><table class="table"><thead><tr><th>File / folder</th><th>Purpose</th></tr></thead><tbody><tr><td class="code">file_inbox_report.xlsx</td><td>Summary, manifest, exceptions, and organize plan</td></tr><tr><td class="code">manifest.csv</td><td>Every file with type, hash, metadata, status, and target</td></tr><tr><td class="code">exceptions.csv</td><td>Duplicate, quarantine, and ignore events with action taken</td></tr><tr><td class="code">organize_plan.csv</td><td>Source-to-target plan with copy or skip action</td></tr><tr><td class="code">organized/ duplicates/ quarantine/</td><td>Safe copies for review; source remains untouched</td></tr></tbody></table><div class="card" style="margin-top:10px"><h3>Run it</h3><p class="code">python src/file_inbox.py --input-dir data/raw/inbox --output-dir data/processed<br>python src/file_inbox.py ... --apply</p><p class="note">The first command is a dry run. Add --apply only after reviewing the plan.</p></div><h2 style="font-size:20px;margin-top:14px">Test coverage</h2><table class="table"><thead><tr><th>Area</th><th>What is checked</th></tr></thead><tbody><tr><td>File naming</td><td>Spaces, symbols, dates, and extension normalization</td></tr><tr><td>Content detection</td><td>CSV without extension, JSON, PDF magic bytes, corrupt PDF</td></tr><tr><td>Duplicate logic</td><td>SHA-256 match, clean source-name preference, skip copy</td></tr><tr><td>Quarantine logic</td><td>Empty files, malformed CSV, unsupported types</td></tr><tr><td>Safe apply</td><td>Copies into organized/ and leaves the source in place</td></tr><tr><td>End-to-end</td><td>Manifest, exceptions, plan, JSON, and Excel workbook</td></tr></tbody></table></div>
<div class="print-page"><p class="kicker">03 - Scope and fit</p><h2>Small, fixed-scope file automation.</h2><div class="grid2"><div class="card"><h3>Good fit</h3><ul class="list"><li><span class="check">✓</span>Shared drives, download folders, and client intake folders</li><li><span class="check">✓</span>Mixed CSV, JSON, TXT, and typed PDF files</li><li><span class="check">✓</span>Clean naming conventions and audit trails</li><li><span class="check">✓</span>One-off cleanup that may become recurring</li></ul></div><div class="card"><h3>Not a fit</h3><ul class="list"><li><span class="check">—</span>Handwritten scans or low-quality images</li><li><span class="check">—</span>Account passwords or unattended access</li><li><span class="check">—</span>Deleting files without review or retention policy</li><li><span class="check">—</span>"100% accuracy" without a written spec</li></ul></div></div><h2 style="font-size:20px;margin-top:14px">A paid pilot, in three steps</h2><div class="grid3"><div class="step"><b>01</b><strong>Sample folder</strong><span>Send 20-30 representative files and one naming rule.</span></div><div class="step"><b>02</b><strong>Dry-run report</strong><span>Review the manifest, duplicates, exceptions, and plan.</span></div><div class="step"><b>03</b><strong>Apply + handover</strong><span>Copy the approved set and receive the source + README.</span></div></div><h2 style="font-size:20px;margin-top:14px">Sample pack</h2><div class="grid2"><div class="card"><ul class="list"><li><span class="check">✓</span>20-file synthetic inbox</li><li><span class="check">✓</span>Excel report + 3 CSV/JSON outputs</li><li><span class="check">✓</span>Safe organize / duplicate / quarantine folders</li></ul></div><div class="card"><ul class="list"><li><span class="check">✓</span>10 automated tests</li><li><span class="check">✓</span>README + dependency list</li><li><span class="check">✓</span>Case page + 80-second demo video</li></ul></div></div><p style="margin-top:12px;font-size:15px;font-weight:800">Send one sample folder and the exact output naming rule.</p><p>I will confirm fit, scope, and a fixed price before work starts. The first run is a dry run; you review the manifest and exception log before any file is copied.</p><h2 style="font-size:20px;margin-top:14px">Engagement options</h2><table class="table"><thead><tr><th>Package</th><th>Scope</th><th>Starting point</th></tr></thead><tbody><tr><td>Basic audit</td><td>One folder, up to 50 files, dry-run report</td><td>Fiverr $75</td></tr><tr><td>Standard workflow</td><td>Up to 200 files, naming rules, safe apply, source + README</td><td>Fiverr $150 / Contra $250</td></tr><tr><td>Premium workflow</td><td>Multi-folder rules, PDF metadata, recurring runbook, handover</td><td>Fiverr $300 / Contra $500+</td></tr></tbody></table><p class="note">Final quote depends on file types, folder structure, naming rules, and review volume. No unlimited revisions.</p><p class="note" style="position:absolute;bottom:.45in;left:.62in;right:.62in">Independent demo. Synthetic files only. No off-platform payment or contact. AI-assisted build, human-reviewed and tested.</p></div>
"""
    path = DOCS / "case-study-print.html"
    path.write_text(page("Boyi Automation - File Inbox Case Study", body, PRINT_CSS), encoding="utf-8")
    return path


def build_gig_pages() -> dict[str, Path]:
    cover = f"""<div class="canvas"><div class="rings"></div><div class="brand">● BOYI AUTOMATION</div><div class="kicker" style="margin-top:54px">INDEPENDENT DEMO - SYNTHETIC FILES</div><div class="title">Messy file inbox.<br><em>Clean, auditable folder.</em></div><div class="sub">Python automation for naming, duplicate detection, validation, and a safe copy plan.</div><div class="chips"><div class="chip">CSV</div><div class="chip">JSON</div><div class="chip">TXT</div><div class="chip">PDF</div><div class="chip">SHA-256</div><div class="chip">Dry run</div></div><div class="metrics"><div class="metric"><b>{fmt_int(summary["files_scanned"])}</b><span>files scanned</span></div><div class="metric"><b>{fmt_int(summary["accepted"])}</b><span>organized</span></div><div class="metric"><b>{fmt_int(summary["duplicates"])}</b><span>duplicates skipped</span></div><div class="metric"><b>10/10</b><span>tests passed</span></div></div><div class="footer">Fixed scope - source included - human QA</div></div>"""
    before_after = f"""<div class="canvas"><div class="rings"></div><div class="brand">● BOYI AUTOMATION</div><div class="kicker" style="margin-top:42px">BEFORE -> AFTER</div><div class="title" style="font-size:58px">No silent duplicates.<br><em>No mystery files.</em></div><div class="cols"><div class="col"><h3>Messy inbox</h3><p>Mixed names, copies, and broken exports.</p><div class="stack"><div class="file bad">VENDOR LIST FINAL (3).CSV<span>name noise</span></div><div class="file bad">vendor list final (3) copy.csv<span>duplicate</span></div><div class="file bad">march statement copy.pdf<span>duplicate</span></div><div class="file bad">broken_export.csv<span>malformed</span></div><div class="file bad">empty.csv<span>empty</span></div><div class="file bad">logo.png<span>unsupported</span></div></div></div><div class="col"><h3>Clean output</h3><p>Every file has a status, a reason, and a target.</p><div class="stack"><div class="file good">2026-03-01_csv_vendor-list-final-3.csv<span>organized</span></div><div class="file good">duplicates/vendor-list-final-3-copy.csv<span>kept for review</span></div><div class="file good">duplicates/march-statement-copy.pdf<span>kept for review</span></div><div class="file good">quarantine/broken_export.csv<span>manual review</span></div><div class="file good">quarantine/empty.csv<span>manual review</span></div><div class="file good">quarantine/logo.png<span>unsupported</span></div></div></div></div><div class="bottom"><b>Dry run first. Copy only with --apply.</b><span>manifest.csv - exceptions.csv - organize_plan.csv - xlsx report</span></div></div>"""
    workflow = f"""<div class="canvas"><div class="rings"></div><div class="brand">● BOYI AUTOMATION</div><div class="kicker" style="margin-top:42px">WORKFLOW</div><div class="title" style="font-size:62px">One folder.<br><em>Five visible decisions.</em></div><div class="steps"><div class="step"><b>01</b><strong>Scan</strong><span>Names, sizes, SHA-256 hashes.</span></div><div class="step"><b>02</b><strong>Detect</strong><span>CSV, JSON, TXT, PDF, or content sniffing.</span></div><div class="step"><b>03</b><strong>Validate</strong><span>Empty, malformed, corrupt, unsupported.</span></div><div class="step"><b>04</b><strong>Plan</strong><span>Organize, skip, ignore, or quarantine.</span></div><div class="step"><b>05</b><strong>Apply</strong><span>Safe copy + manifest + audit log.</span></div></div><div class="bottom"><b>Python - pathlib - hashlib - csv - openpyxl - pypdf</b><span>No source file is deleted. No account credentials required.</span></div></div>"""
    contra = f"""<div class="canvas" style="padding:64px 76px"><div class="rings"></div><div class="brand" style="font-size:18px">● BOYI AUTOMATION</div><div class="kicker" style="margin-top:88px">PYTHON FILE AUTOMATION</div><div class="title" style="font-size:94px;max-width:1200px">Messy folder.<br><em>Clean system.</em></div><div class="sub" style="font-size:28px;max-width:1120px;margin-top:24px">Scan, classify, deduplicate, validate, normalize, and package a safe folder cleanup - with a manifest and exception log.</div><div class="metrics" style="margin-top:54px"><div class="metric" style="min-width:210px;padding:18px 22px"><b style="font-size:38px">{fmt_int(summary["files_scanned"])}</b><span style="font-size:12px">files scanned</span></div><div class="metric" style="min-width:210px;padding:18px 22px"><b style="font-size:38px">{fmt_int(summary["accepted"])}</b><span style="font-size:12px">organized</span></div><div class="metric" style="min-width:210px;padding:18px 22px"><b style="font-size:38px">{fmt_int(summary["duplicates"])}</b><span style="font-size:12px">duplicates skipped</span></div><div class="metric" style="min-width:210px;padding:18px 22px"><b style="font-size:38px">10/10</b><span style="font-size:12px">tests passed</span></div></div><div class="chips" style="margin-top:34px"><div class="chip" style="font-size:19px">Dry run first</div><div class="chip" style="font-size:19px">SHA-256 dedupe</div><div class="chip" style="font-size:19px">Source included</div><div class="chip" style="font-size:19px">Excel + CSV + JSON</div></div><div class="footer" style="font-size:16px;bottom:46px">Independent demo - synthetic files - fixed scope - human QA</div></div>"""
    pages = {
        "cover": (DOCS / "gig-01-cover.html", page("Gig cover", cover, GIG_CSS, '<style>body{margin:0}</style>')),
        "before_after": (DOCS / "gig-02-before-after.html", page("Before after", before_after, GIG_CSS, '<style>body{margin:0}</style>')),
        "workflow": (DOCS / "gig-03-workflow.html", page("Workflow", workflow, GIG_CSS, '<style>body{margin:0}</style>')),
        "contra": (DOCS / "contra-cover.html", page("Contra cover", contra, GIG_CSS, '<style>body{margin:0}</style>')),
    }
    result = {}
    for key, (path, content) in pages.items():
        path.write_text(content, encoding="utf-8")
        result[key] = path
    return result

def chrome_screenshot(html_path: Path, png_path: Path, width: int, height: int) -> None:
    profile = BUILD / "chrome-profile"
    cmd = [str(CHROME), "--headless=new", "--disable-gpu", "--hide-scrollbars", "--no-sandbox", f"--user-data-dir={profile}", f"--window-size={width},{height}", f"--screenshot={png_path}", html_path.as_uri()]
    subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
    if not png_path.exists() or png_path.stat().st_size == 0:
        raise RuntimeError(f"Screenshot failed: {png_path}")


def chrome_pdf(html_path: Path, pdf_path: Path) -> None:
    profile = BUILD / "chrome-pdf-profile"
    cmd = [str(CHROME), "--headless=new", "--disable-gpu", "--no-sandbox", "--no-pdf-header-footer", f"--user-data-dir={profile}", f"--print-to-pdf={pdf_path}", html_path.as_uri()]
    subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=90)
    if not pdf_path.exists() or pdf_path.stat().st_size == 0:
        raise RuntimeError(f"PDF failed: {pdf_path}")


def copy_samples() -> None:
    for name in ("manifest.csv", "exceptions.csv", "organize_plan.csv", "run_summary.json", "file_inbox_report.xlsx"):
        shutil.copy2(ROOT / "data" / "processed" / name, SAMPLE / name)
    zip_path = SAMPLE / "messy_inbox_sample.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted((ROOT / "data" / "raw" / "inbox").iterdir()):
            if path.is_file():
                archive.write(path, arcname=path.name)


def main() -> None:
    copy_samples()
    case_path = build_case_page()
    print_path = build_print_page()
    gig_pages = build_gig_pages()
    outputs = {
        "cover": (ASSETS / "gig-01-cover.png", 1280, 769),
        "before_after": (ASSETS / "gig-02-before-after.png", 1280, 769),
        "workflow": (ASSETS / "gig-03-workflow.png", 1280, 769),
        "contra": (ASSETS / "contra-cover.png", 1600, 1200),
    }
    mapping = {"cover": gig_pages["cover"], "before_after": gig_pages["before_after"], "workflow": gig_pages["workflow"], "contra": gig_pages["contra"]}
    for key, (png, width, height) in outputs.items():
        chrome_screenshot(mapping[key], png, width, height)
        print(f"image: {png}")
    pdf_path = DOCS / "case-study.pdf"
    chrome_pdf(print_path, pdf_path)
    print(f"pdf: {pdf_path}")
    chrome_screenshot(case_path, ASSETS / "case-preview.png", 1600, 1000)
    print(f"image: {ASSETS / 'case-preview.png'}")
    for src in (ASSETS / "gig-01-cover.png", ASSETS / "gig-02-before-after.png", ASSETS / "gig-03-workflow.png", ASSETS / "contra-cover.png"):
        shutil.copy2(src, PORT / "images" / src.name)
    shutil.copy2(pdf_path, PORT / "pdf" / "case-study.pdf")
    shutil.copy2(case_path, PORT / "case-study.html")
    for name in ("manifest.csv", "exceptions.csv", "organize_plan.csv", "run_summary.json", "file_inbox_report.xlsx", "messy_inbox_sample.zip"):
        shutil.copy2(SAMPLE / name, PORT / "copy" / name)
    manifest_data = {
        "project": "python-file-automation-flagship",
        "demo_label": "Independent demo - synthetic files",
        "metrics": summary,
        "assets": {
            "case_page": str(case_path),
            "pdf": str(pdf_path),
            "fiverr_images": [str(ASSETS / "gig-01-cover.png"), str(ASSETS / "gig-02-before-after.png"), str(ASSETS / "gig-03-workflow.png")],
            "contra_cover": str(ASSETS / "contra-cover.png"),
            "samples": [str(SAMPLE / name) for name in ("manifest.csv", "exceptions.csv", "organize_plan.csv", "run_summary.json", "file_inbox_report.xlsx", "messy_inbox_sample.zip")],
        },
    }
    (DOCS / "asset-manifest.json").write_text(json.dumps(manifest_data, indent=2), encoding="utf-8")
    shutil.copy2(DOCS / "asset-manifest.json", PORT / "copy" / "asset-manifest.json")
    print("assets built")


if __name__ == "__main__":
    main()

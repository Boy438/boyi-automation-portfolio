from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import imageio_ffmpeg
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"
ASSETS = DOCS / "assets"
BUILD = ROOT / "build" / "video"
PORT = Path(r"D:\FreelanceWorkbench\04_portfolio\python-file-automation")
BUILD.mkdir(parents=True, exist_ok=True)
PORT.joinpath("video").mkdir(parents=True, exist_ok=True)

summary = json.loads((ROOT / "data" / "processed" / "run_summary.json").read_text(encoding="utf-8"))
W, H = 1600, 900
NAVY = (11, 18, 32)
LIME = (183, 243, 74)
MUTED = (170, 181, 196)
WHITE = (255, 255, 255)
CORAL = (255, 107, 94)
FONT_BOLD = Path(r"C:\Windows\Fonts\segoeuib.ttf")
FONT_REG = Path(r"C:\Windows\Fonts\segoeui.ttf")
FONT_MONO = Path(r"C:\Windows\Fonts\consola.ttf")


def font(path: Path, size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(str(path), size=size)


def base_slide(label: str) -> tuple[Image.Image, ImageDraw.ImageDraw]:
    img = Image.new("RGB", (W, H), NAVY)
    d = ImageDraw.Draw(img)
    for r in (330, 390, 450):
        d.ellipse((W - r - 120, -r + 20, W - 120 + r, 20 + r), outline=(30, 48, 43), width=2)
    d.text((84, 68), "●  BOYI AUTOMATION", font=font(FONT_BOLD, 24), fill=LIME)
    right = "INDEPENDENT DEMO · SYNTHETIC FILES"
    d.text((W - 84 - d.textlength(right, font=font(FONT_BOLD, 18)), 72), right, font=font(FONT_BOLD, 18), fill=LIME)
    d.text((84, H - 52), label, font=font(FONT_REG, 18), fill=MUTED)
    return img, d


def title_slide() -> Image.Image:
    img, d = base_slide("01 / 07")
    d.text((84, 188), "Messy file inbox.", font=font(FONT_BOLD, 84), fill=WHITE)
    d.text((84, 284), "Clean, auditable folder.", font=font(FONT_BOLD, 82), fill=LIME)
    d.text((84, 420), "A deterministic Python workflow for naming, duplicate detection,", font=font(FONT_REG, 28), fill=MUTED)
    d.text((84, 464), "validation, quarantine, and a safe copy plan.", font=font(FONT_REG, 28), fill=MUTED)
    metrics = [(str(summary["files_scanned"]), "FILES SCANNED"), (str(summary["accepted"]), "ORGANIZED"), (str(summary["duplicates"]), "DUPLICATES SKIPPED"), ("10/10", "TESTS PASSED")]
    x0, y0, w, gap = 84, 590, 340, 22
    for i, (value, label) in enumerate(metrics):
        x = x0 + i * (w + gap)
        d.rounded_rectangle((x, y0, x + w, y0 + 122), radius=18, fill=(23, 34, 52), outline=(42, 58, 78), width=1)
        d.text((x + 24, y0 + 20), value, font=font(FONT_BOLD, 42), fill=LIME)
        d.text((x + 24, y0 + 78), label, font=font(FONT_BOLD, 16), fill=MUTED)
    return img


def problem_slide() -> Image.Image:
    img, d = base_slide("02 / 07")
    d.text((84, 150), "A folder is not a system.", font=font(FONT_BOLD, 58), fill=WHITE)
    d.text((84, 232), "Names, copies, broken exports, and unsupported files.", font=font(FONT_REG, 28), fill=MUTED)
    issues = [
        ("VENDOR LIST FINAL (3).CSV", "name noise"),
        ("vendor list final (3) copy.csv", "duplicate"),
        ("march statement copy.pdf", "duplicate"),
        ("broken_export.csv", "malformed"),
        ("empty.csv", "empty"),
        ("logo.png", "unsupported"),
    ]
    y = 330
    for bad, desc in issues:
        d.rounded_rectangle((84, y, 860, y + 56), radius=12, fill=(22, 32, 48), outline=(45, 60, 80), width=1)
        d.text((110, y + 14), bad, font=font(FONT_MONO, 21), fill=CORAL)
        d.text((620, y + 14), desc, font=font(FONT_REG, 21), fill=(225, 231, 239))
        y += 66
    d.rounded_rectangle((920, 330, 1516, 810), radius=18, fill=(16, 26, 41), outline=(45, 60, 80), width=1)
    d.text((960, 366), "What changes", font=font(FONT_BOLD, 30), fill=LIME)
    bullets = [
        "Dry run before any copy",
        "SHA-256 duplicate detection",
        "Visible exception log",
        "Safe source folder",
    ]
    yy = 438
    for item in bullets:
        d.text((964, yy), "✓", font=font(FONT_BOLD, 26), fill=LIME)
        d.text((1006, yy), item, font=font(FONT_REG, 26), fill=(225, 231, 239))
        yy += 70
    return img


def image_slide(path: Path, label: str, caption: str) -> Image.Image:
    img = Image.new("RGB", (W, H), NAVY)
    src = Image.open(path).convert("RGB")
    scale = max(W / src.width, H / src.height)
    resized = src.resize((int(src.width * scale), int(src.height * scale)), Image.LANCZOS)
    left = (resized.width - W) // 2
    top = (resized.height - H) // 2
    img.paste(resized.crop((left, top, left + W, top + H)), (0, 0))
    overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    od = ImageDraw.Draw(overlay)
    od.rectangle((0, 0, W, 100), fill=(11, 18, 32, 220))
    od.rectangle((0, H - 96, W, H), fill=(11, 18, 32, 235))
    img = Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")
    d = ImageDraw.Draw(img)
    d.text((84, 34), "●  BOYI AUTOMATION", font=font(FONT_BOLD, 22), fill=LIME)
    d.text((84, H - 68), caption, font=font(FONT_BOLD, 26), fill=WHITE)
    d.text((W - 84 - d.textlength(label, font=font(FONT_BOLD, 18)), 36), label, font=font(FONT_BOLD, 18), fill=LIME)
    return img


def validation_slide() -> Image.Image:
    img, d = base_slide("06 / 07")
    d.text((84, 150), "Bad files are not hidden.", font=font(FONT_BOLD, 58), fill=WHITE)
    d.text((84, 232), "They are explained, separated, and kept for review.", font=font(FONT_REG, 28), fill=MUTED)
    rows = [
        ("10 / 10", "automated tests passed"),
        (str(summary["duplicates"]), "duplicate files skipped"),
        (str(summary["quarantined"]), "files moved to quarantine"),
        (str(summary["audit_events"]), "visible audit events"),
    ]
    y = 330
    for value, label in rows:
        d.rounded_rectangle((84, y, 1516, y + 92), radius=14, fill=(22, 32, 48), outline=(45, 60, 80), width=1)
        d.text((118, y + 20), value, font=font(FONT_BOLD, 36), fill=LIME)
        d.text((430, y + 28), label, font=font(FONT_REG, 26), fill=(225, 231, 239))
        y += 108
    d.text((84, 790), "Manifest · exceptions · organize plan · Excel report.", font=font(FONT_REG, 24), fill=MUTED)
    return img


def cta_slide() -> Image.Image:
    img, d = base_slide("07 / 07")
    d.text((84, 190), "Need this for your folder?", font=font(FONT_BOLD, 70), fill=WHITE)
    d.text((84, 292), "Send one sample folder and your naming rule.", font=font(FONT_REG, 30), fill=MUTED)
    d.text((84, 342), "I will confirm scope and a fixed price before work starts.", font=font(FONT_REG, 30), fill=MUTED)
    d.rounded_rectangle((84, 470, 1516, 674), radius=22, fill=(23, 34, 52), outline=LIME, width=2)
    d.text((120, 510), "Dry run first  ·  source included  ·  human QA", font=font(FONT_BOLD, 40), fill=LIME)
    d.text((120, 578), "No client names, logos, testimonials, or revenue claims. Synthetic files only.", font=font(FONT_REG, 24), fill=MUTED)
    d.text((84, 760), "boyi-automation  /  independent demo", font=font(FONT_BOLD, 22), fill=WHITE)
    return img


def build_slides() -> list[tuple[Path, int]]:
    slides = [
        ("01-title.png", title_slide(), 10),
        ("02-problem.png", problem_slide(), 11),
        ("03-before-after.png", image_slide(ASSETS / "gig-02-before-after.png", "03 / 07", "Before → after: every file has a status"), 13),
        ("04-workflow.png", image_slide(ASSETS / "gig-03-workflow.png", "04 / 07", "Five visible decisions, one audit trail"), 13),
        ("05-cover.png", image_slide(ASSETS / "gig-01-cover.png", "05 / 07", "Python does the repetitive work"), 13),
        ("06-validation.png", validation_slide(), 10),
        ("07-cta.png", cta_slide(), 10),
    ]
    result = []
    for name, image, duration in slides:
        path = BUILD / name
        image.save(path)
        result.append((path, duration))
    return result


def build_video() -> Path:
    slides = build_slides()
    concat = BUILD / "concat.txt"
    with concat.open("w", encoding="utf-8") as handle:
        for path, duration in slides:
            handle.write(f"file '{path.as_posix()}'\nduration {duration}\n")
    out = ASSETS / "demo.mp4"
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    cmd = [ffmpeg, "-y", "-f", "concat", "-safe", "0", "-i", str(concat), "-vf", "fps=24,format=yuv420p", "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-movflags", "+faststart", str(out)]
    subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180)
    shutil.copy2(out, PORT / "video" / "demo.mp4")
    frames = []
    for path, _ in slides[:4]:
        im = Image.open(path).convert("RGB").resize((960, 540), Image.LANCZOS)
        frames.append(im)
    gif = ASSETS / "demo-preview.gif"
    frames[0].save(gif, save_all=True, append_images=frames[1:], duration=[1200] * len(frames), loop=0)
    shutil.copy2(gif, PORT / "video" / "demo-preview.gif")
    return out


if __name__ == "__main__":
    out = build_video()
    print(out)

# Python File Inbox Automation

**Messy file folder -> normalized, deduplicated, auditable output — with a dry run first.**

> **Independent demo — synthetic files.** No client names, logos, testimonials, or revenue claims are used. All files are generated for this portfolio case study.

## Snapshot

| Metric | Result |
|---|---:|
| Files scanned | 20 |
| Organized | 9 |
| Duplicate files skipped | 4 |
| Quarantined | 4 |
| Ignored system/template files | 3 |
| Audit events | 11 |
| Automated tests | 10 / 10 passed |
| Full pipeline runtime | ~0.03s |

The runtime is measured on the generated 20-file demo folder. It is a benchmark, not a promise for every client folder or network drive.

## What it does

1. **Scan** — walks a folder and reads file names, sizes, and SHA-256 checksums.
2. **Detect** — identifies CSV, JSON, TXT, and PDF files; content-sniffs files with no extension.
3. **Inspect** — reads basic metadata: CSV rows/columns, JSON record counts, text line/word counts, and PDF page counts.
4. **Deduplicate** — keeps the cleanest source name and marks byte-identical copies as duplicates.
5. **Quarantine** — separates empty, malformed, unsupported, or corrupt files instead of silently deleting them.
6. **Organize** — writes an audit-first plan and, only with `--apply`, copies accepted files into normalized names under `organized/`.

The original inbox is never deleted or modified.

## Outputs

| File / folder | Purpose |
|---|---|
| `data/processed/file_inbox_report.xlsx` | Client-ready summary, manifest, exceptions, and organize plan |
| `data/processed/manifest.csv` | Every file with type, hash, status, metadata, and normalized name |
| `data/processed/exceptions.csv` | Duplicate, quarantine, and ignore events with the action taken |
| `data/processed/organize_plan.csv` | Source-to-target plan with copy/skip action |
| `data/processed/run_summary.json` | Machine-readable run metrics |
| `data/processed/organized/` | Normalized copies of accepted files |
| `data/processed/duplicates/` | Copies of duplicate files, kept for review |
| `data/processed/quarantine/` | Copies of files that need manual attention |

## Quick start

```powershell
python -m pip install -r requirements.txt
python src/generate_sample_data.py
python src/file_inbox.py --input-dir data/raw/inbox --output-dir data/processed
python -m unittest discover -s tests -v
```

The default command is a **dry run**: it writes the report and plan but does not copy or move files.

To copy the planned outputs:

```powershell
python src/file_inbox.py --input-dir data/raw/inbox --output-dir data/processed --apply
```

Or rebuild the full demo, tests, images, PDF, and video:

```powershell
powershell -ExecutionPolicy Bypass -File .\run_demo.ps1
```

## Example file types

- `VENDOR LIST FINAL (3).CSV`
- `customer_export_2026-03-01.json`
- `notes from kickoff 03-05-2026.txt`
- `march_statement.pdf`
- `export_without_extension` — detected as CSV from its content
- `.DS_Store`, `README`, `~$orders.xlsx` — ignored as system/template files

The demo also includes duplicate copies, an empty CSV, a malformed CSV, a corrupt PDF, and an unsupported image.

## Validation rules in this demo

- File names are normalized to `date_type_stem.ext`
- Dates are extracted from ISO, slash, hyphen, and month-name file names
- Byte-identical files are detected with SHA-256
- Unsupported extensions and corrupt PDF signatures are quarantined
- Empty files and malformed CSV column counts are quarantined
- System/template files are ignored but still listed in the manifest
- Duplicate resolution prefers the cleanest source name, not whichever file appears first

Ambiguous dates such as `03/05/2026` are parsed as month/day/year in this demo. A real project should confirm the date convention before work starts.

## Project structure

```
config/rules.json             allowed types, ignored names, size limit, date formats
src/generate_sample_data.py   deterministic synthetic inbox generator
src/file_inbox.py             scan, detect, metadata, dedupe, report, safe copy
src/build_assets.py           case page, gig images, PDF
src/build_video.py            captioned 80-second demo video
tests/test_file_inbox.py      10 unit and end-to-end tests
docs/index.html               interactive proof page
docs/case-study.pdf           one-page-per-section PDF case study
docs/sample/                  downloadable sample outputs and raw sample zip
```

## Limitations

- The demo does not connect to Google Drive, Dropbox, SharePoint, email, or a database.
- The default action is non-destructive; `--apply` copies files but does not delete the source.
- PDF metadata is limited to page count and extractable first-page text.
- Scanned/image-only PDFs are flagged for manual review, not treated as extracted text.
- A real project must define naming conventions, retention rules, and duplicate policy before work starts.
- No account credentials are required for a first sample run.

## AI disclosure

AI-assisted build, human-reviewed and tested. The runtime pipeline is deterministic and does not call an external model. If a client wants AI-assisted classification or extraction added, that is scoped separately. The client receives the working files, source code, and a short test/exception report.

## Live case page

If this repository is published as a GitHub Pages site from the `docs/` folder, the case page is available at:

`https://<your-github-user>.github.io/<repo-name>/`

## License

No license is granted for client data. The demo code is provided as a portfolio sample. Add a license before accepting third-party contributions or redistributing the code.

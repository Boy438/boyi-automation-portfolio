from __future__ import annotations

import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from file_inbox import (  # noqa: E402
    Rules,
    detect_type,
    extract_date_hint,
    normalize_name,
    run,
    scan_folder,
)


class NamingTests(unittest.TestCase):
    def test_normalize_name_cleans_spaces_and_symbols(self) -> None:
        self.assertEqual(
            normalize_name("VENDOR LIST FINAL (3).CSV", "csv", "2026-03-01"),
            "2026-03-01_csv_vendor-list-final-3.csv",
        )

    def test_date_hint_iso_and_month_name(self) -> None:
        rules = Rules()
        self.assertEqual(extract_date_hint("orders 2026_03_07.csv", rules.date_formats), "2026-03-07")
        self.assertEqual(extract_date_hint("notes 03-05-2026.txt", rules.date_formats), "2026-03-05")
        self.assertEqual(extract_date_hint("March 5 2026.txt", rules.date_formats), "2026-03-05")

    def test_normalized_name_without_date(self) -> None:
        self.assertEqual(normalize_name("supplier prices.csv", "csv", ""), "undated_csv_supplier-prices.csv")


class DetectionTests(unittest.TestCase):
    def test_detect_csv_without_extension_by_content(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "export_no_ext"
            path.write_text("id,name,amount\n1,Alpha,12.00\n2,Beta,15.00\n", encoding="utf-8")
            self.assertEqual(detect_type(path, [".csv", ".json", ".txt", ".pdf"]), "csv")

    def test_detect_json(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "customers.json"
            path.write_text(json.dumps([{"id": 1}]), encoding="utf-8")
            self.assertEqual(detect_type(path, [".csv", ".json", ".txt", ".pdf"]), "json")

    def test_detect_pdf_magic_and_reject_corrupt_pdf(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            good = Path(tmp) / "good.pdf"
            good.write_bytes(b"%PDF-1.4\n")
            bad = Path(tmp) / "bad.pdf"
            bad.write_text("not a pdf", encoding="utf-8")
            self.assertEqual(detect_type(good, [".csv", ".json", ".txt", ".pdf"]), "pdf")
            self.assertEqual(detect_type(bad, [".csv", ".json", ".txt", ".pdf"]), "unknown")


class FolderTests(unittest.TestCase):
    def test_duplicate_content_is_skipped(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            inbox = Path(tmp) / "inbox"
            inbox.mkdir()
            payload = "id,name\n1,Alpha\n2,Beta\n"
            (inbox / "vendors.csv").write_text(payload, encoding="utf-8")
            (inbox / "vendors copy.csv").write_text(payload, encoding="utf-8")
            records, events = scan_folder(inbox, Rules())
            self.assertEqual(sum(record.status == "accepted" for record in records), 1)
            self.assertEqual(sum(record.status == "duplicate" for record in records), 1)
            self.assertTrue(any(event.issue == "duplicate_content" for event in events))

    def test_system_files_are_ignored(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            inbox = Path(tmp) / "inbox"
            inbox.mkdir()
            (inbox / ".DS_Store").write_bytes(b"hidden")
            (inbox / "README").write_text("readme", encoding="utf-8")
            records, events = scan_folder(inbox, Rules())
            self.assertEqual({record.status for record in records}, {"ignored"})
            self.assertEqual(len(events), 2)

    def test_broken_csv_and_empty_file_are_quarantined(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            inbox = Path(tmp) / "inbox"
            inbox.mkdir()
            (inbox / "broken.csv").write_text('id,name\n1,"Bob\n', encoding="utf-8")
            (inbox / "empty.csv").write_text("", encoding="utf-8")
            records, events = scan_folder(inbox, Rules())
            self.assertEqual(sum(record.status == "quarantined" for record in records), 2)
            self.assertTrue(any("empty_file" in event.issue for event in events))

    def test_end_to_end_outputs_and_apply(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            inbox = Path(tmp) / "inbox"
            out = Path(tmp) / "out"
            inbox.mkdir()
            (inbox / "orders 2026_03_07.csv").write_text("id,name,amount\n1,Alpha,12.00\n", encoding="utf-8")
            (inbox / "notes.txt").write_text("hello world\n", encoding="utf-8")
            summary = run(inbox, out, Rules(), apply=True)
            self.assertEqual(summary["files_scanned"], 2)
            self.assertEqual(summary["accepted"], 2)
            for name in ("manifest.csv", "exceptions.csv", "organize_plan.csv", "run_summary.json", "file_inbox_report.xlsx"):
                self.assertTrue((out / name).exists(), name)
            organized = list((out / "organized").iterdir())
            self.assertEqual(len(organized), 2)
            self.assertTrue((inbox / "orders 2026_03_07.csv").exists())


if __name__ == "__main__":
    unittest.main()
